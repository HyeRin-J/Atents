﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExpContact : MonoBehaviour {
    PlayerLevel playerLevel;


	// Use this for initialization
	void Start () {
        playerLevel = FindObjectOfType<PlayerLevel>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Hazzards"))
        {
            playerLevel.playerExp += 10;
        }
        if (other.CompareTag("Enemy"))
        {
            if (other.GetComponent<DestroyByContact>().hp <= 0)
                playerLevel.playerExp += 15;
            else
                other.GetComponent<DestroyByContact>().hp -= playerLevel.boltDamage;
        }
    }
}
