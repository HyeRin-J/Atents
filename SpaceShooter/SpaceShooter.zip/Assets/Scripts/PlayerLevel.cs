﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerLevel : MonoBehaviour {
    public Text levelText;
    public Slider ExpBar;

    public int playerLevel = 1;
    public float playerExp;
    public float boltDamage = 1;

    // Use this for initialization
    void Start () {
        playerLevel = 0;
        playerExp = 0.0f;
    }
	
	// Update is called once per frame
	void Update () {
        ExpBar.value = playerExp / 100.0f;
		if(playerExp >= 100)
        {
            playerLevel++;
            levelText.text = "LV : " + playerLevel;
            playerExp -= 100;
            boltDamage *= 1.5f;
        }
	}
}
