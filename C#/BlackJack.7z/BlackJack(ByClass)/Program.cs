﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackJack_ByClass_
{
    class Program
    {
        static void Main(string[] args)
        {
            Card cards = new Card(52);
            Dealer dealer = new Dealer();
            Player[] player = new Player[4];
        }
    }

    public class Card
    {
        public int[] cards;
        public bool isStay = false, hasAce = false, hasTen = false, isBlackjack = false, isBust = false;
        public int cardSum = 0, cardIndex = 0;

        public Card(int n)
        {
            Random rand = new Random();
            cards = new int[n];

            for (int i = 0; i < n; i++)
            {
                cards[i] = i + 1;
            }

            for (int i = 0; i < n; i++)
            {
                int k = rand.Next(n);
                int temp = cards[i];
                cards[i] = cards[k];
                cards[k] = temp;
            }
        }
        public Card() { }

        public bool HasAce()
        {
            for (int i = 0; i < cards.Length; i++)
            {
                if (cards[i] % 13 == 1)
                    hasAce = true;
            }
            return hasAce;
        }
        public bool HasTen()
        {
            for (int i = 0; i < cards.Length; i++)
            {
                if (cards[i] % 13 == 0 || cards[i] % 13 >= 10)
                    hasTen = true;
            }
            return hasAce;
        }
        public void SumCards()
        {
            cardSum = 0;
            for (int i = 0; i < cards.Length; i++)
            {
                if (cards[i] != 0)
                {
                    int num = cards[i] % 13;
                    switch (num)
                    {
                        case 1:
                            num = 11;
                            break;
                        case 11:
                        case 12:
                        case 0:
                            num = 10;
                            break;
                        default:
                            break;
                    }
                    cardSum += num;
                }
            }
        }
        public void PrintAllCards()
        {
            for(int i = 0; i < cards.Length; i++)
            {
                PrintCard(cards[i]);
                Console.Write(", ");
            }
        }
        public void PrintCard(int card)
        {
            if ((card - 1) / 13 == 0)
            {
                Console.Write("♤");
                if (card % 13 == 1)
                    Console.Write("A");
                else if (card % 13 == 11)
                    Console.Write("J");
                else if (card % 13 == 12)
                    Console.Write("Q");
                else if (card % 13 == 0)
                    Console.Write("K");
                else
                    Console.Write("{0}", card % 13);
            }
            else if ((card - 1) / 13 == 1)
            {
                Console.Write("◇");

                if (card % 13 == 1)
                    Console.Write("A");
                else if (card % 13 == 11)
                    Console.Write("J");
                else if (card % 13 == 12)
                    Console.Write("Q");
                else if (card % 13 == 0)
                    Console.Write("K");
                else
                    Console.Write("{0}", card % 13);
            }
            else if ((card - 1) / 13 == 2)
            {
                Console.Write("♡");
                if (card % 13 == 1)
                    Console.Write("A");
                else if (card % 13 == 11)
                    Console.Write("J");
                else if (card % 13 == 12)
                    Console.Write("Q");
                else if (card % 13 == 0)
                    Console.Write("K");
                else
                    Console.Write("{0}", card % 13);
            }
            else if ((card - 1) / 13 == 3)
            {
                Console.Write("♧");
                if (card % 13 == 1)
                    Console.Write("A");
                else if (card % 13 == 11)
                    Console.Write("J");
                else if (card % 13 == 12)
                    Console.Write("Q");
                else if (card % 13 == 0)
                    Console.Write("K");
                else
                    Console.Write("{0}", card % 13);
            }
        }
        public int DrawCards()
        {
            int card = cards[cardIndex];
            cardIndex = cardIndex + 1;
            return card;
        }
        public bool IsBust()
        {
            if (cardSum > 21) isBust = true;
            return isBust;
        }
    }

    public class Dealer : Card
    {

    }

    public class Player : Card
    {
        public bool hasSameCard = false;

        public bool HasSameCard()
        {
            for(int i = 0; i < cards.Length; i++)
            {
                for(int j = 0; j < cards.Length; j++)
                {
                    if (cards[i].Equals(cards[j])) hasSameCard = true;
                }
            }

            return hasSameCard = true;
        }
    }
}
